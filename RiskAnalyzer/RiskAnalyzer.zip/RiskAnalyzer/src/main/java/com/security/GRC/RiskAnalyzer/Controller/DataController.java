package com.security.GRC.RiskAnalyzer.Controller;

import com.security.GRC.RiskAnalyzer.Connection.DbConnection;
import com.security.GRC.RiskAnalyzer.Services.DataGetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLDataException;
import java.sql.SQLException;

@RestController
@RequestMapping("/read")
public class DataController {
@Autowired
    DbConnection dbConnection;
@Autowired
    DataGetService dataGetService;
@GetMapping("/get")
    public ResponseEntity<?> readData(@RequestBody String Role) throws SQLException {
    return dataGetService.execute(Role);

}
}
